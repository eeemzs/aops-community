# @aopslab/aops-cli

AOPS Community operator CLI for an existing local or remote AOPS server.

Install globally with `npm install --global @aopslab/aops-cli`, or run once with
`npx --yes --package @aopslab/aops-cli aops-cli --help`.

The public source distribution is available with
`git clone https://github.com/eeemzs/aops-community.git`.
